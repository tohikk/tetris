import React from "react";
import Empty from "../../components/Empty/Empty";
import "./Cart.css";

function Cart() {
  return (
    <div className="container cart">
      <Empty />
    </div>
  );
}

export default Cart;
