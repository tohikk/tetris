export const PRODUCTS = [
  {
    id: "pro-1",
    title: "Kungaboqar yog'i Щедрое лето, tozalangan, 900 ml",
    price: 14_000,
    url: "https://images.uzum.uz/chm61nt6sfhndlbmo1sg/t_product_540_high.jpg#1686561237205",
  },
  {
    id: "pro-2",
    title: "Havo sovutgich Roniq Oasis Max",
    price: 799_000,
    url: "https://images.uzum.uz/chicl2540v9pplt1uu7g/original.jpg",
  },
  {
    id: "pro-3",
    title: "Qo'l soati Smart Zeblaze Beyond 2",
    price: 393_000,
    url: "https://images.uzum.uz/ci05n7d6sfhndlbno2bg/original.jpg",
  },
  {
    id: "pro-4",
    title: "Aqlli soat Smart Watch X8 ULTRA, 49 mm",
    price: 355_000,
    url: "https://images.uzum.uz/cfmcsnfhgiopn8lcdgg0/original.jpg",
  },
  {
    id: "pro-5",
    title: "Robot-changyutgich Ardesto RVC-S600W",
    price: 1_800_000,
    url: "https://images.uzum.uz/ci1ffp36edfostigiqn0/original.jpg",
  },
];
